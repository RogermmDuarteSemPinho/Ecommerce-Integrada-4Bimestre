<?php
require_once 'config/database.php';

$q = trim((string)($_GET['q'] ?? ''));
$cat = filter_input(INPUT_GET, 'categoria', FILTER_VALIDATE_INT) ?: 0;

$cats = $pdo->query('SELECT id, nome FROM categorias ORDER BY nome')->fetchAll();

$sql = 'SELECT p.id, p.nome, p.descricao, p.preco, p.estoque, p.imagem,
               c.nome AS categoria, p.categoria_id
        FROM produtos p
        LEFT JOIN categorias c ON c.id = p.categoria_id
        WHERE p.ativo = 1';
$params = [];
if ($q !== '') {
    $sql .= ' AND (p.nome LIKE ? OR p.descricao LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}
if ($cat > 0) {
    $sql .= ' AND p.categoria_id = ?';
    $params[] = $cat;
}
$sql .= ' ORDER BY p.criado_em DESC, p.id DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$pageTitle = 'Loja';
require 'includes/header.php';

$categoryIcons = [
    'Computadores' => 'bi-pc-display',
    'Periféricos' => 'bi-keyboard',
    'Componentes' => 'bi-cpu',
    'Games' => 'bi-controller'
];
?>
<style>
.store-hero{position:relative;overflow:hidden;margin:26px auto 34px;padding:clamp(32px,6vw,70px);border-radius:24px;color:#fff;background:radial-gradient(circle at 88% 18%,rgba(151,141,255,.42),transparent 30%),linear-gradient(115deg,#171923 0%,#29265b 58%,#6558e8 100%)}
.store-hero:after{content:"TS";position:absolute;right:5%;bottom:-85px;color:#ffffff0d;font-size:clamp(13rem,28vw,23rem);font-weight:800;letter-spacing:-.12em;line-height:1;pointer-events:none}
.store-hero-content{position:relative;z-index:1}.store-hero .eyebrow{display:inline-block;padding:7px 11px;border:1px solid #ffffff38;border-radius:30px;color:#e7e4ff;background:#ffffff12;letter-spacing:1px}
.store-hero h1{max-width:650px;margin:20px 0 14px;font:800 clamp(2.4rem,5vw,4.2rem)/1.04 'Space Grotesk';letter-spacing:-2.5px}
.store-hero p{max-width:510px;color:#d6d5eb;line-height:1.75}.hero-device{display:grid;place-items:center;width:min(240px,75%);aspect-ratio:1;margin:auto;border:1px solid #ffffff40;border-radius:38% 62% 55% 45% / 45% 42% 58% 55%;background:#ffffff1a;box-shadow:0 25px 80px #0003,inset 0 0 45px #ffffff14;transform:rotate(-8deg)}
.hero-device i{color:white;font-size:7rem;transform:rotate(8deg)}
.store-benefit{display:flex;align-items:center;gap:13px;height:100%;padding:17px;border:1px solid var(--line);border-radius:15px;background:#fff}
.store-benefit-icon{display:grid;place-items:center;flex:0 0 42px;width:42px;height:42px;border-radius:12px;color:var(--violet);background:#f0efff;font-size:1.2rem}
.store-benefit strong{display:block;font-size:.88rem}.store-benefit small{color:var(--muted);font-size:.76rem}
.store-category{display:flex;align-items:center;gap:13px;width:100%;padding:17px;border:1px solid var(--line);border-radius:15px;color:var(--ink);background:#fff;text-align:left;transition:.2s}
.store-category:hover,.store-category.selected{border-color:#c8c3ff;background:#f7f6ff;transform:translateY(-2px)}
.store-category i{color:var(--violet);font-size:1.45rem}.store-category span{font-weight:700;font-size:.9rem}
.store-product-card{height:100%;overflow:hidden;border:1px solid var(--line);border-radius:17px;background:white;transition:.22s}
.store-product-card:hover{transform:translateY(-4px);box-shadow:0 16px 35px #1e21370d}
.store-product-img{position:relative;display:grid;place-items:center;height:190px;margin:10px;overflow:hidden;border-radius:12px;background:linear-gradient(145deg,#f2f2fa,#e9eaf4)}
.store-product-img img{width:100%;height:100%;object-fit:cover}.store-product-img .placeholder{color:#5e5a83;font-size:5rem}
.store-product-body{padding:7px 17px 17px}.store-product-category{color:var(--muted);font-size:.7rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase}
.store-product-name{min-height:43px;margin:7px 0;font:600 .98rem/1.35 'Space Grotesk'}
.store-price{font-size:1.2rem;font-weight:800;letter-spacing:-.5px;color:var(--violet)}
.store-stock{font-size:.75rem;font-weight:700}.store-stock.available{color:#16865c}.store-stock.out{color:#b54747}
.store-add{width:100%;padding:10px;border:0;border-radius:10px;color:#fff;background:#182036;font-size:.84rem;font-weight:700}
.store-add:hover{background:var(--violet)}.store-search{border-radius:12px!important;padding:12px 14px!important}
.store-promo{overflow:hidden;border-radius:20px;color:#fff;background:linear-gradient(105deg,#28254f,#6558e8)}
.store-promo p{color:#dcdaf7}
@media(max-width:767px){.store-hero{border-radius:18px}.hero-device{width:155px;margin-top:25px}.hero-device i{font-size:5rem}}
</style>

<div class="container">
  <section class="store-hero">
    <div class="row align-items-center">
      <div class="col-lg-8 store-hero-content py-2">
        <span class="eyebrow"><i class="bi bi-stars me-1"></i> Seu próximo upgrade começa aqui</span>
        <h1>Tecnologia que acompanha o seu ritmo.</h1>
        <p>Encontre periféricos, componentes e acessórios para estudar, trabalhar, jogar e criar. Tudo em um só lugar.</p>
        <a class="btn btn-light fw-bold px-4 py-3 mt-2" href="#catalogo">Explorar produtos <i class="bi bi-arrow-right ms-2"></i></a>
      </div>
      <div class="col-lg-4 position-relative" style="z-index:1">
        <div class="hero-device"><i class="bi bi-pc-display"></i></div>
      </div>
    </div>
  </section>

  <section class="row g-3 mb-5">
    <div class="col-12 col-md-4"><div class="store-benefit"><span class="store-benefit-icon"><i class="bi bi-shield-check"></i></span><div><strong>Compra segura</strong><small>Seus dados protegidos</small></div></div></div>
    <div class="col-12 col-md-4"><div class="store-benefit"><span class="store-benefit-icon"><i class="bi bi-box-seam"></i></span><div><strong>Produtos selecionados</strong><small>Qualidade para seu setup</small></div></div></div>
    <div class="col-12 col-md-4"><div class="store-benefit"><span class="store-benefit-icon"><i class="bi bi-headset"></i></span><div><strong>Suporte ao cliente</strong><small>Ajuda quando precisar</small></div></div></div>
  </section>

  <section class="mb-5">
    <div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
      <div><h2 class="section-title mb-1">Explore por categoria</h2><p class="muted mb-0">Encontre rapidamente o que você procura.</p></div>
      <a class="small fw-bold text-decoration-none" href="index.php">Ver todas</a>
    </div>
    <div class="row g-3">
      <?php foreach ($cats as $c): ?>
        <div class="col-6 col-md-3">
          <a class="store-category text-decoration-none <?=$cat === (int)$c['id'] ? 'selected' : ''?>" href="index.php?categoria=<?=(int)$c['id']?>">
            <i class="bi <?=e($categoryIcons[$c['nome']] ?? 'bi-grid')?>"></i>
            <span><?=e($c['nome'])?></span>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section id="catalogo" class="mb-5">
    <div class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-4">
      <div><span class="eyebrow">Seleção TechStore</span><h2 class="section-title mb-1 mt-1">Produtos em destaque</h2><p class="muted mb-0">Produtos carregados diretamente do banco de dados.</p></div>
      <span class="muted"><?=count($products)?> produto(s) encontrado(s)</span>
    </div>

    <form method="get" action="index.php" class="row g-2 mb-4">
      <div class="col-md-6"><input class="form-control store-search" type="search" name="q" value="<?=e($q)?>" placeholder="Buscar produto..." aria-label="Buscar produto"></div>
      <div class="col-md-4">
        <select class="form-select store-search" name="categoria" aria-label="Filtrar por categoria">
          <option value="">Todas as categorias</option>
          <?php foreach ($cats as $c): ?>
            <option value="<?=(int)$c['id']?>" <?=$cat === (int)$c['id'] ? 'selected' : ''?>><?=e($c['nome'])?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-grid"><button class="btn btn-primary"><i class="bi bi-search me-1"></i> Buscar</button></div>
    </form>

    <div class="row g-3">
      <?php if (!$products): ?>
        <div class="col-12"><div class="panel text-center py-5"><i class="bi bi-search display-5 muted"></i><h3 class="h5 mt-3">Nenhum produto encontrado</h3><p class="muted mb-0">Tente alterar a busca ou escolher outra categoria.</p></div></div>
      <?php endif; ?>

      <?php foreach ($products as $p): ?>
        <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
          <article class="store-product-card">
            <a href="produto.php?id=<?=(int)$p['id']?>" class="text-decoration-none">
              <div class="store-product-img">
                <?php if (!empty($p['imagem'])): ?>
                  <img src="<?=e($p['imagem'])?>" alt="<?=e($p['nome'])?>">
                <?php else: ?>
                  <span class="placeholder"><i class="bi bi-cpu"></i></span>
                <?php endif; ?>
              </div>
            </a>
            <div class="store-product-body">
              <div class="store-product-category"><?=e($p['categoria'] ?? 'Sem categoria')?></div>
              <h3 class="store-product-name"><?=e($p['nome'])?></h3>
              <p class="muted small"><?=e(mb_strimwidth((string)($p['descricao'] ?? ''), 0, 88, '…'))?></p>
              <div class="store-price mb-2"><?=money($p['preco'])?></div>
              <?php if ((int)$p['estoque'] > 0): ?>
                <div class="store-stock available mb-3"><i class="bi bi-check-circle-fill me-1"></i><?= (int)$p['estoque'] ?> disponíveis</div>
                <form method="post" action="carrinho.php">
                  <input type="hidden" name="_csrf" value="<?=e(csrf())?>">
                  <input type="hidden" name="acao" value="adicionar">
                  <input type="hidden" name="id" value="<?=(int)$p['id']?>">
                  <input type="hidden" name="quantidade" value="1">
                  <button class="store-add" type="submit"><i class="bi bi-bag-plus me-2"></i>Adicionar ao carrinho</button>
                </form>
              <?php else: ?>
                <div class="store-stock out mb-3"><i class="bi bi-x-circle me-1"></i>Produto esgotado</div>
                <button class="store-add" type="button" disabled style="opacity:.5;cursor:not-allowed">Indisponível</button>
              <?php endif; ?>
              <a href="produto.php?id=<?=(int)$p['id']?>" class="d-block text-center small mt-3 text-decoration-none">Ver detalhes do produto</a>
            </div>
          </article>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="store-promo p-4 p-md-5 mb-5">
    <div class="row align-items-center">
      <div class="col-lg-8"><span class="small fw-bold text-uppercase" style="color:#d9d5ff">Monte seu espaço</span><h2 class="fw-bold mt-2 mb-2" style="letter-spacing:-1px">Seu setup, suas possibilidades.</h2><p class="mb-0">Escolha os equipamentos que combinam com a sua rotina e dê o próximo passo.</p></div>
      <div class="col-lg-4 text-lg-end mt-3 mt-lg-0"><a href="#catalogo" class="btn btn-light rounded-3 fw-bold px-4 py-3">Encontrar produtos <i class="bi bi-arrow-up-right ms-2"></i></a></div>
    </div>
  </section>
</div>
<?php require 'includes/footer.php'; ?>
