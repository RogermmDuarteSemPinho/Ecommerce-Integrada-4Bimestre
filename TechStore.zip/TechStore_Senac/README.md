# TechStore — E-commerce | Atividade final Senac

Aplicação acadêmica de comércio eletrônico desenvolvida com PHP, MySQL/MariaDB, PDO, HTML5, CSS3, Bootstrap 5 e JavaScript.

## Requisitos implementados
- Catálogo dinâmico do banco, busca e filtro por categoria.
- Página de detalhes com preço, descrição, imagem e disponibilidade.
- Cadastro/login com `password_hash()` e `password_verify()`.
- Carrinho via `$_SESSION`: adicionar, atualizar quantidade, remover e calcular subtotal/total.
- Checkout exige autenticação e simula PIX, boleto ou cartão.
- Pedido, itens com preço unitário congelado, baixa de estoque e limpeza do carrinho em transação.
- Painel administrativo protegido por perfil.
- CRUD de produtos (criar, listar, editar e ativar/desativar), cadastro de categorias e visualização de pedidos/itens.
- PDO com prepared statements, proteção CSRF e escape de saída.

## Instalação local (XAMPP)
1. Copie a pasta `TechStore_Senac` para `C:\\xampp\\htdocs\\`.
2. Copie `.env.example` para `.env` e ajuste host, porta, banco, usuário e senha.
3. Inicie Apache e MySQL no XAMPP.
4. Importe `database/schema.sql` pelo phpMyAdmin.
5. Acesse `http://localhost/TechStore_Senac/`.
6. Crie um usuário na tela de cadastro.
7. Para conceder perfil de administrador, execute no phpMyAdmin, trocando pelo e-mail cadastrado:
   `UPDATE usuarios SET perfil='admin' WHERE email='seu-email@exemplo.com';`
8. Saia e entre novamente. O link Painel aparecerá no menu.

## Git / entrega
O arquivo `.env` está no `.gitignore`; envie apenas `.env.example`, nunca suas credenciais reais.
O enunciado exige repositório remoto GitHub/GitLab e histórico de commits durante o desenvolvimento. O ZIP serve apenas para transferir os arquivos ao computador; não substitui o link do repositório.

Exemplo de sequência de commits:
- `chore: estrutura inicial e configuração`
- `feat: catálogo, busca e categorias`
- `feat: autenticação e carrinho`
- `feat: checkout e registro de pedidos`
- `feat: painel administrativo e CRUD`
- `style: identidade visual responsiva`

## Observações
- Pagamentos são simulados; não há cobrança real.
- Imagens podem ser informadas por URL pública.
- Para produção, acrescente HTTPS, política de privacidade, rate limiting, logs, validação mais abrangente e integração com gateway de pagamento.


## Integração da vitrine com o banco de dados
A página inicial `index.php` usa a conexão PDO definida em `config/database.php` e consulta as tabelas `produtos` e `categorias` do `database/schema.sql`. A busca e o filtro são enviados por GET e usam prepared statements. Os cartões mostram preço, imagem e estoque do registro real. O botão "Adicionar ao carrinho" envia um POST com token CSRF para `carrinho.php`, que mantém as quantidades em `$_SESSION` e valida o estoque no servidor. Portanto, não abra o arquivo por duplo clique: execute pelo Apache/XAMPP em `http://localhost/TechStore_Senac/`.

A vitrine não usa mais a lista fixa de produtos do HTML demonstrativo anterior. Para cadastrar ou alterar os produtos exibidos, use o painel administrativo ou edite os dados de teste em `database/schema.sql`.
