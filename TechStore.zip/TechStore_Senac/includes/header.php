<?php
require_once __DIR__.'/../config/database.php';
$pageTitle=$pageTitle ?? 'Início';
$base = str_contains($_SERVER['PHP_SELF'],'/admin/') ? '../' : '';
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=e($pageTitle)?> | TechStore</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link href="<?=$base?>assets/css/style.css" rel="stylesheet"></head><body>
<nav class="navbar navbar-expand-lg navbar-dark nav-main"><div class="container"><a class="navbar-brand" href="<?=$base?>index.php"><b class="brand-icon">T</b> tech<span>store</span></a>
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="nav"><div class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
<a class="nav-link" href="<?=$base?>index.php">Loja</a>
<?php if(is_admin()):?><a class="nav-link" href="<?=$base?>admin/index.php">Painel</a><?php endif;?>
<?php if(logged()):?><span class="nav-user">Olá, <?=e($_SESSION['user']['nome'])?></span><a class="nav-link" href="<?=$base?>logout.php">Sair</a><?php else:?><a class="nav-link" href="<?=$base?>login.php">Entrar</a><a class="nav-link" href="<?=$base?>cadastro.php">Criar conta</a><?php endif;?>
<a class="btn btn-cart" href="<?=$base?>carrinho.php">Carrinho <span><?=cart_count()?></span></a>
</div></div></div></nav><main class="flex-grow-1"><div class="container pt-3"><?php show_flash();?></div>
