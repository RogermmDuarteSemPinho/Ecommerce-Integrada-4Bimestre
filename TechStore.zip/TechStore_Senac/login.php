<?php
require_once 'config/database.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();$email=filter_var(trim($_POST['email']??''),FILTER_VALIDATE_EMAIL);$pass=$_POST['senha']??'';$s=$pdo->prepare('SELECT id,nome,email,senha,perfil FROM usuarios WHERE email=?');$s->execute([$email?:'']);$u=$s->fetch();
 if($u&&password_verify($pass,$u['senha'])){session_regenerate_id(true);$_SESSION['user']=['id'=>(int)$u['id'],'nome'=>$u['nome'],'perfil'=>$u['perfil']];go('index.php');}$error='E-mail ou senha incorretos.';}
$pageTitle='Entrar';require 'includes/header.php';?>
<div class="container content" style="max-width:540px"><div class="form-panel"><div class="eyebrow">Acesse sua conta</div><h1 class="page-title mt-2">Bem-vindo de volta</h1><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><div class="mb-3"><label class="form-label">E-mail</label><input class="form-control" type="email" name="email" required></div><div class="mb-4"><label class="form-label">Senha</label><input class="form-control" type="password" name="senha" required></div><button class="btn btn-primary w-100">Entrar</button></form><p class="text-center muted mt-3">Não tem conta? <a href="cadastro.php">Cadastre-se</a></p></div></div>
<?php require 'includes/footer.php';?>
