CREATE DATABASE IF NOT EXISTS techstore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE techstore;
CREATE TABLE usuarios (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 senha VARCHAR(255) NOT NULL,
 perfil ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE categorias (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL UNIQUE,
 descricao VARCHAR(255) NULL
) ENGINE=InnoDB;
CREATE TABLE produtos (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 categoria_id INT UNSIGNED NULL,
 nome VARCHAR(160) NOT NULL,
 descricao TEXT NULL,
 preco DECIMAL(10,2) NOT NULL,
 estoque INT UNSIGNED NOT NULL DEFAULT 0,
 imagem VARCHAR(500) NULL,
 ativo TINYINT(1) NOT NULL DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_prod_categoria FOREIGN KEY(categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE pedidos (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT UNSIGNED NOT NULL,
 data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 forma_pagamento ENUM('PIX','BOLETO','CARTAO') NOT NULL,
 valor_total DECIMAL(10,2) NOT NULL,
 status VARCHAR(40) NOT NULL DEFAULT 'Confirmado',
 CONSTRAINT fk_pedido_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
) ENGINE=InnoDB;
CREATE TABLE pedido_itens (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 pedido_id INT UNSIGNED NOT NULL,
 produto_id INT UNSIGNED NULL,
 nome_produto VARCHAR(160) NOT NULL,
 quantidade INT UNSIGNED NOT NULL,
 preco_unitario DECIMAL(10,2) NOT NULL,
 CONSTRAINT fk_item_pedido FOREIGN KEY(pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
 CONSTRAINT fk_item_produto FOREIGN KEY(produto_id) REFERENCES produtos(id) ON DELETE SET NULL
) ENGINE=InnoDB;
INSERT INTO categorias(nome,descricao) VALUES
('Computadores','Notebooks e desktops'),('Periféricos','Acessórios para computador'),('Componentes','Peças e upgrades'),('Games','Produtos para jogar');
INSERT INTO produtos(categoria_id,nome,descricao,preco,estoque,imagem) VALUES
(2,'Mouse sem fio','Mouse ergonômico para o dia a dia.',89.90,25,''),
(2,'Teclado mecânico','Teclado mecânico para produtividade e jogos.',249.90,12,''),
(3,'SSD 1 TB','Armazenamento rápido para seu computador.',399.90,8,''),
(4,'Headset gamer','Headset confortável com microfone.',179.90,15,'');
-- Após cadastrar sua conta pela loja, transforme-a em administradora:
-- UPDATE usuarios SET perfil='admin' WHERE email='seu-email@exemplo.com';
