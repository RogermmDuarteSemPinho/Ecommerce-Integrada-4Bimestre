<?php
require_once 'config/bootstrap.php';$_SESSION=[];session_destroy();header('Location: index.php');exit;
