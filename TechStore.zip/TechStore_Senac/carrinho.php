<?php
require_once 'config/database.php';check_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $action=$_POST['acao']??'';$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT)?:0;
 if($action==='adicionar'){
  $qty=filter_input(INPUT_POST,'quantidade',FILTER_VALIDATE_INT)?:0;$s=$pdo->prepare('SELECT estoque,ativo FROM produtos WHERE id=?');$s->execute([$id]);$p=$s->fetch();
  if(!$p||!$p['ativo']||$qty<1||$qty>(int)$p['estoque']){flash('Quantidade indisponível.','danger');go('produto.php?id='.$id);}
  $_SESSION['cart'][$id]=min((int)($_SESSION['cart'][$id]??0)+$qty,(int)$p['estoque']);flash('Produto adicionado ao carrinho.');go('carrinho.php');
 }
 if($action==='atualizar'){
  foreach($_POST['quantidades']??[] as $pid=>$qty){$pid=(int)$pid;$qty=(int)$qty;$s=$pdo->prepare('SELECT estoque,ativo FROM produtos WHERE id=?');$s->execute([$pid]);$p=$s->fetch();if(!$p||!$p['ativo']||$qty<1)unset($_SESSION['cart'][$pid]);else $_SESSION['cart'][$pid]=min($qty,(int)$p['estoque']);}
  flash('Carrinho atualizado.');go('carrinho.php');
 }
}
if(isset($_GET['remover'])){unset($_SESSION['cart'][(int)$_GET['remover']]);flash('Item removido.');go('carrinho.php');}
[$items,$total]=cart_data($pdo);$pageTitle='Carrinho';require 'includes/header.php';?>
<div class="container content"><h1 class="page-title mb-4">Seu carrinho</h1><?php if(!$items):?><div class="panel text-center py-5"><div class="display-4">⌑</div><h2 class="section-title">Seu carrinho está vazio</h2><p class="muted">Explore o catálogo para encontrar seu próximo produto.</p><a href="index.php" class="btn btn-primary">Ver produtos</a></div><?php else:?><div class="row g-4"><div class="col-lg-8"><form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><input type="hidden" name="acao" value="atualizar"><div class="panel p-0 overflow-hidden"><div class="table-responsive"><table class="table mb-0"><thead><tr><th class="ps-4">Produto</th><th>Preço</th><th>Quantidade</th><th>Subtotal</th><th></th></tr></thead><tbody><?php foreach($items as $p):?><tr><td class="ps-4"><div class="d-flex align-items-center gap-2"><?php if($p['imagem']):?><img class="thumb" src="<?=e($p['imagem'])?>" alt=""><?php else:?><span class="thumb d-grid place-items-center">⌘</span><?php endif;?><strong><?=e($p['nome'])?></strong></div></td><td><?=money($p['preco'])?></td><td><input class="form-control" style="width:85px" type="number" min="1" max="<?=$p['estoque']?>" name="quantidades[<?=$p['id']?>]" value="<?=$p['quantidade']?>"></td><td><?=money($p['subtotal'])?></td><td><a class="text-danger" href="carrinho.php?remover=<?=$p['id']?>">Remover</a></td></tr><?php endforeach;?></tbody></table></div></div><button class="btn btn-outline-secondary mt-3">Atualizar quantidades</button></form></div><div class="col-lg-4"><div class="summary"><h2 class="section-title fs-5">Resumo do pedido</h2><div class="d-flex justify-content-between my-3"><span class="muted">Total</span><strong class="price"><?=money($total)?></strong></div><a class="btn btn-primary w-100" href="checkout.php">Continuar para checkout</a></div></div></div><?php endif;?></div>
<?php require 'includes/footer.php';?>
