<?php
require_once '../config/database.php';need_admin();check_csrf();if($_SERVER['REQUEST_METHOD']!=='POST')go('produtos.php');$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT)?:0;$s=$pdo->prepare('UPDATE produtos SET ativo=IF(ativo=1,0,1) WHERE id=?');$s->execute([$id]);flash('Status do produto atualizado.');go('produtos.php');
