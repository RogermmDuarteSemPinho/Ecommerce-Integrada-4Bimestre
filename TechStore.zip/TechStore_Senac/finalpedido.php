<?php
require_once 'config/database.php';need_login();check_csrf();if($_SERVER['REQUEST_METHOD']!=='POST')go('checkout.php');$method=$_POST['pagamento']??'';if(!in_array($method,['PIX','BOLETO','CARTAO'],true))go('checkout.php');
try{$pdo->beginTransaction();$cart=$_SESSION['cart']??[];if(!$cart)throw new RuntimeException();
 $locked=[];$total=0.0;
 foreach($cart as $id=>$qty){$s=$pdo->prepare('SELECT id,nome,preco,estoque,ativo FROM produtos WHERE id=? FOR UPDATE');$s->execute([(int)$id]);$p=$s->fetch();$qty=(int)$qty;if(!$p||!$p['ativo']||$qty<1||$qty>(int)$p['estoque'])throw new RuntimeException();$p['quantidade']=$qty;$total+=(float)$p['preco']*$qty;$locked[]=$p;}
 $s=$pdo->prepare("INSERT INTO pedidos(usuario_id,forma_pagamento,valor_total,status) VALUES(?,?,?,'Confirmado')");$s->execute([$_SESSION['user']['id'],$method,$total]);$orderId=(int)$pdo->lastInsertId();
 $ins=$pdo->prepare('INSERT INTO pedido_itens(pedido_id,produto_id,nome_produto,quantidade,preco_unitario) VALUES(?,?,?,?,?)');$upd=$pdo->prepare('UPDATE produtos SET estoque=estoque-? WHERE id=?');
 foreach($locked as $p){$ins->execute([$orderId,$p['id'],$p['nome'],$p['quantidade'],$p['preco']]);$upd->execute([$p['quantidade'],$p['id']]);}
 $pdo->commit();unset($_SESSION['cart']);
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('Não foi possível finalizar. Confira seu carrinho e o estoque.','danger');go('carrinho.php');}
$pageTitle='Pedido confirmado';require 'includes/header.php';?>
<div class="container content" style="max-width:650px"><div class="form-panel text-center py-5"><div class="display-3">✓</div><div class="eyebrow">Pedido registrado</div><h1 class="page-title mt-2">Compra confirmada!</h1><p class="muted">Pedido #<?=$orderId?> registrado com sucesso.</p><p>Pagamento: <strong><?=e($method)?></strong><br>Total: <strong class="price"><?=money($total)?></strong></p><a href="index.php" class="btn btn-primary mt-3">Voltar à loja</a></div></div>
<?php require 'includes/footer.php';?>
