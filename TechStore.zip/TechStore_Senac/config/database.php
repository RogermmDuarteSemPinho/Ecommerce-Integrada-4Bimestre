<?php
require_once __DIR__.'/bootstrap.php';
try { $pdo=db(); } catch (PDOException $e) { http_response_code(500); exit('Falha na conexão. Confira o arquivo .env e importe database/schema.sql.'); }
