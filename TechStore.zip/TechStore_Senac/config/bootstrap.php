<?php
declare(strict_types=1);
$envFile = dirname(__DIR__) . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim(trim($value), "\"'");
    }
}
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('techstore_session');
    session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']),'samesite'=>'Lax']);
    session_start();
}
function envv(string $key, string $default=''): string { return (string)($_ENV[$key] ?? getenv($key) ?: $default); }
function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host='.envv('DB_HOST','127.0.0.1').';port='.envv('DB_PORT','3306').';dbname='.envv('DB_NAME','techstore').';charset=utf8mb4';
    $pdo = new PDO($dsn, envv('DB_USER','root'), envv('DB_PASS'), [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false
    ]);
    return $pdo;
}
function e(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function money(float|string $v): string { return 'R$ '.number_format((float)$v,2,',','.'); }
function go(string $to): never { header('Location: '.$to); exit; }
function csrf(): string { if (empty($_SESSION['_csrf'])) $_SESSION['_csrf']=bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function check_csrf(): void {
    if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['_csrf'] ?? '', $_POST['_csrf'] ?? '')) {
        http_response_code(403); exit('Solicitação inválida. Atualize a página e tente novamente.');
    }
}
function logged(): bool { return !empty($_SESSION['user']['id']); }
function need_login(): void { if (!logged()) go('login.php'); }
function is_admin(): bool { return logged() && ($_SESSION['user']['perfil'] ?? '')==='admin'; }
function need_admin(): void { if (!is_admin()) { http_response_code(403); exit('Acesso restrito à administração.'); } }
function flash(string $msg, string $type='success'): void { $_SESSION['_flash']=['msg'=>$msg,'type'=>$type]; }
function show_flash(): void { if (!empty($_SESSION['_flash'])) { $f=$_SESSION['_flash']; unset($_SESSION['_flash']); echo '<div class="alert alert-'.e($f['type']).'">'.e($f['msg']).'</div>'; } }
function cart_count(): int { return array_sum($_SESSION['cart'] ?? []); }
function cart_data(PDO $pdo): array {
    $items=[]; $total=0.0;
    foreach ($_SESSION['cart'] ?? [] as $id=>$qty) {
        $st=$pdo->prepare('SELECT id,nome,preco,imagem,estoque,ativo FROM produtos WHERE id=?');
        $st->execute([(int)$id]); $p=$st->fetch();
        if (!$p || !(int)$p['ativo'] || (int)$p['estoque']<1) { unset($_SESSION['cart'][$id]); continue; }
        $qty=min(max(1,(int)$qty),(int)$p['estoque']); $_SESSION['cart'][$id]=$qty;
        $p['quantidade']=$qty; $p['subtotal']=$qty*(float)$p['preco']; $total+=$p['subtotal']; $items[]=$p;
    }
    return [$items,$total];
}
