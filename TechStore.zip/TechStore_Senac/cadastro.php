<?php
require_once 'config/database.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){check_csrf();$name=trim($_POST['nome']??'');$email=filter_var(trim($_POST['email']??''),FILTER_VALIDATE_EMAIL);$pass=$_POST['senha']??'';
 if($name===''||!$email||strlen($pass)<8)$error='Informe nome, e-mail válido e senha com pelo menos 8 caracteres.';
 else{try{$s=$pdo->prepare("INSERT INTO usuarios(nome,email,senha,perfil) VALUES(?,?,?,'cliente')");$s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);session_regenerate_id(true);$_SESSION['user']=['id'=>(int)$pdo->lastInsertId(),'nome'=>$name,'perfil'=>'cliente'];go('index.php');}catch(PDOException $e){$error='Este e-mail já está cadastrado.';}}
}
$pageTitle='Criar conta';require 'includes/header.php';?>
<div class="container content" style="max-width:560px"><div class="form-panel"><div class="eyebrow">Bem-vindo à TechStore</div><h1 class="page-title mt-2">Crie sua conta</h1><p class="muted">Cadastre-se para realizar suas compras.</p><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><div class="mb-3"><label class="form-label">Nome</label><input class="form-control" name="nome" maxlength="120" required></div><div class="mb-3"><label class="form-label">E-mail</label><input class="form-control" type="email" name="email" required></div><div class="mb-4"><label class="form-label">Senha</label><input class="form-control" type="password" name="senha" minlength="8" required></div><button class="btn btn-primary w-100">Cadastrar</button></form><p class="text-center muted mt-3">Já tem conta? <a href="login.php">Entrar</a></p></div></div>
<?php require 'includes/footer.php';?>
